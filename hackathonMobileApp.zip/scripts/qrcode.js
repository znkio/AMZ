document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
    navigator.splashscreen.hide();
    var app = new App();
    app.run();
}

function App() {
}


var app = {
                // Application Constructor
                initialize: function() {
                    this.bindEvents();
                },
                // Bind Event Listeners
                //
                // Bind any events that are required on startup. Common events are:
                // 'load', 'deviceready', 'offline', and 'online'.
                bindEvents: function() {
                    document.addEventListener('deviceready', this.onDeviceReady, false);
                },
                // deviceready Event Handler
                //
                // The scope of 'this' is the event. In order to call the 'receivedEvent'
                // function, we must explicity call 'app.receivedEvent(...);'
                onDeviceReady: function() {
                    app.receivedEvent('deviceready');
                    navigator.splashscreen.hide();
                }
            };
            
            
            
           
            
            





App.prototype = {
    resultsField: null,
     
    run: function() {
        var that = this,
        scanButton = document.getElementById("scanButton");
        
        that.resultsField = document.getElementById("result");
        
        scanButton.addEventListener("click",
                                    function() { 
                                        that._scan.call(that); 
                                    });
    },
    
    _scan: function() {
        var that = this;
        if (window.navigator.simulator === true) {
            alert("Not Supported in Simulator.");
        }
        else {
            cordova.plugins.barcodeScanner.scan(
                function(result) {
                    if (!result.cancelled) {
                        that._addMessageToLog(result.format + " | " + result.text);    
                    }
                }, 
                function(error) {
                    console.log("Scanning failed: " + error);
                });
        }
    },

    _addMessageToLog: function(message) {
        //var that = this,
        //currentMessage = that.resultsField.innerHTML;
        
        //that.resultsField.innerHTML = currentMessage + message + '<br />'; 
        
        
        var ref = window.open(message.replace("QR_CODE | ",""), '_blank', 'location=yes');
                ref.addEventListener('loadstart', function(event) { 
                    if (event.url.indexOf("closebr") > 0) {
                        var parser = document.createElement('a');
                        parser.href = event.url;
            
                        console.log(parser.protocol); // => "http:"
                        console.log(parser.hostname); // => "example.com"
                        console.log(parser.port);     // => "3000"
                        console.log(parser.pathname); // => "/pathname/"
                        console.log(parser.search);   // => "?search=test"
                        console.log(parser.hash);     // => "#hash"
                        console.log(parser.host);     // => "example.com:3000"
            
                        ref.close();
                        if (parser.hash == "#qrcode") {
                            window.location = "qrcode.html";
                        }
                    }    
                });
                ref.addEventListener('loadstop', function(event) {
                });
                ref.addEventListener('loaderror', function(event) {
                });
                ref.addEventListener('exit', function(event) {

                });
                globalBroswer = ref;
        
        
        
    }
}